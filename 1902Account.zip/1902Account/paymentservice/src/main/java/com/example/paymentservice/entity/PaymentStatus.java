package com.example.paymentservice.entity;

public enum PaymentStatus {
    PENDING,
    COMPLETED,
    FAILED
}