package com.example.support_service.entity;

public enum TicketStatus {
    NEW,
    ASSIGNED,
    IN_PROGRESS,
    RESOLVED,
    CLOSED
}