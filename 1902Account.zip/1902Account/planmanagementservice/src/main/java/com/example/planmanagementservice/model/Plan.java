package com.example.planmanagementservice.model;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@Table(name = "plans")
public class Plan {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    
    private String name;
    private String description;
    private BigDecimal price;
    private Integer duration; // in days
    private Integer dataLimit; // in GB
//    @ColumnDefault(value = "0")
    private Integer smsLimit;// in Number
//    @ColumnDefault(value = "0")
//    private String talkTimeMinutes; // in Minutes
//    @Column(name = "talk_time_minutes", nullable = false)
    private String talkTimeMinutes;


    @ElementCollection
    @CollectionTable(name = "plan_features", joinColumns = @JoinColumn(name = "plan_id"))
    @Column(name = "feature")
    private List<String> features;
    
    private boolean active;
    
    @Column(updatable = false)
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}