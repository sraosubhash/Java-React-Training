package com.example.planmanagementservice.repository;

import com.example.planmanagementservice.model.UserPlan;
import com.example.planmanagementservice.model.PlanStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserPlanRepository extends JpaRepository<UserPlan, String> {
    List<UserPlan> findByUserIdOrderByStartDateDesc(String userId);
    long countByUserIdAndStatusIn(String userId, List<PlanStatus> statuses);
    Optional<UserPlan> findByUserIdAndStatus(String userId, PlanStatus status);
    List<UserPlan> findByStatusIn(List<PlanStatus> statuses);
}