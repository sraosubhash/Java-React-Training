package com.example.planmanagementservice.dto;

import lombok.Data;
import jakarta.validation.constraints.NotBlank;

@Data
public class PlanSubscriptionRequest {
    @NotBlank(message = "User ID is required")
    private String userId;
    
    @NotBlank(message = "Plan ID is required")
    private String planId;
}