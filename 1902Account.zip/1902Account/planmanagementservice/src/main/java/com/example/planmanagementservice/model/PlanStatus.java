package com.example.planmanagementservice.model;

public enum PlanStatus {
    ACTIVE,
    UPCOMING,
    EXPIRED
}