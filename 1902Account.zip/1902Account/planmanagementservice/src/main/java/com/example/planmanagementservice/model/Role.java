package com.example.planmanagementservice.model;

public enum Role {
    EMPLOYEE,
    USER,
    ADMIN
}
