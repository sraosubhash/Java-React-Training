package com.example.planmanagementservice.service;

import com.example.planmanagementservice.dto.*;
import org.apache.log4j.Logger;
import com.example.planmanagementservice.model.Plan;
import com.example.planmanagementservice.exception.PlanManagementException;
import com.example.planmanagementservice.mapper.PlanMapper;
import com.example.planmanagementservice.repository.PlanRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class PlanService {
    private final PlanRepository planRepository;
    private final PlanMapper planMapper;
    private Logger log = Logger.getLogger(PlanService.class);
    String  pp= "Plan not found with id: " ;
    @Transactional
    public PlanResponse createPlan(CreatePlanRequest request) {
        log.info("Creating new plan with name: {}"+ request.getName());

        if (planRepository.existsByName(request.getName())) {
            throw new PlanManagementException("Plan with name " + request.getName() + " already exists");
        }

        Plan plan = planMapper.toEntity(request);
        Plan savedPlan = planRepository.save(plan);
        log.info("Plan created successfully with id: {}"+ savedPlan.getId());

        return planMapper.toResponse(savedPlan);
    }

    @Transactional
    public PlanResponse updatePlan(String id, UpdatePlanRequest request) {
        log.info("Updating plan with id: {}"+ id);

        Plan existingPlan = planRepository.findById(id)
                .orElseThrow(() -> new PlanManagementException(pp + id));

        if (request.getName() != null && 
        	    !request.getName().equals(existingPlan.getName()) && 
        	    planRepository.existsByName(request.getName())) {
        	    
        	    throw new PlanManagementException("Plan with name " + request.getName() + " already exists");
        	}


        planMapper.updateEntity(existingPlan, request);
        Plan updatedPlan = planRepository.save(existingPlan);
        log.info("Plan updated successfully: {}"+ id);

        return planMapper.toResponse(updatedPlan);
    }

    public PlanResponse getPlanById(String id) {
        Plan plan = planRepository.findById(id)
                .orElseThrow(() -> new PlanManagementException(pp + id));
        return planMapper.toResponse(plan);
    }

    public PagedPlanResponse getAllActivePlans(Pageable pageable) {
        Page<Plan> planPage = planRepository.findByActiveTrue(pageable);
        return planMapper.toPagedResponse(planPage);
    }

    @Transactional
    public void deletePlan(String id) {
        Plan plan = planRepository.findById(id)
                .orElseThrow(() -> new PlanManagementException(pp + id));
        plan.setActive(false);
        planRepository.save(plan);
    }

    public boolean validatePlan(String id) {
        return planRepository.existsById(id);
    }
}