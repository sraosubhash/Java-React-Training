package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbCmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbCmsApplication.class, args);
	}

}
