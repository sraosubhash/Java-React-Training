package com.java.jdbc.model;

public enum gender {
	
	Male, Female

}
