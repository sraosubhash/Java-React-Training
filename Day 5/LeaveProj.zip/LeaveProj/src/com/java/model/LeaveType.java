package com.java.model;

public enum LeaveType {
	EL,PL,ML
	

}
