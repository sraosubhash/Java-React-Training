package com.java.leave.model;

public enum LeaveType {
	
	EL, PL, ML

}
