package main;

import java.util.Scanner;
import dao.LeaveDaoImpl;

public class SearchLeaveMain {
    public static void main(String[] args) {
        LeaveDaoImpl dao = new LeaveDaoImpl();
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter Leave ID to search: ");
            int leaveId = scanner.nextInt();

            String searchResult = dao.searchLeaveDetails(leaveId);
            System.out.println(searchResult);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
}
