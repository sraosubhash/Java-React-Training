package model;

public enum LeaveType {

	EL,PL,SL
}
